package car.registration.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;

@Document(collection="Car")

public class Car {
	
	@Id
	private String carId;
	@NotEmpty(message = "Car name required")
	private String carName;
	@Min(500000)
	private String carPrice;
	private String carColor;
	
	public String getCarId() {
		return carId;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getCarPrice() {
		return carPrice;
	}
	public void setCarPrice(String carPrice) {
		this.carPrice = carPrice;
	}
	public String getCarColor() {
		return carColor;
	}
	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}
	public void setCarId(String carId) {
		this.carId = carId;
	}
	public Car(String carId, @NotEmpty(message = "Car name required") String carName, @Min(65778) String carPrice,
			String carColor) {
		super();
		this.carId = carId;
		this.carName = carName;
		this.carPrice = carPrice;
		this.carColor = carColor;
	}
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}


	


	
}
