package car.registration.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import org.springframework.stereotype.Repository;

import car.registration.model.Car;
@Repository

public interface CarRepository extends MongoRepository<Car, String> {

	List<Car> findByCarName(String carName);

}


