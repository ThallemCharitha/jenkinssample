package car.registration.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import car.registration.model.Car;
import car.registration.repository.CarRepository;


@Component
@Service
public class CarService {
	
	@Autowired
	private CarRepository  carrepo;
	
	public List<Car> getAllCarDetails() 
	{
		List<Car> car1 =carrepo.findAll();
		return car1;
	}
	
	public Car addCarDetails(Car car)
	{
		car.setCarId(UUID.randomUUID().toString().split("-")[0]);
		return carrepo.save(car);
	}
	public List<Car> getCarDetails(Car car)
	{
		return carrepo.findAll();
		
	}
	public Car getCarById(String carId)
	{
		return carrepo.findById(carId).get();
		
	}
	public List<Car> getCarByName(String carName)
	{
		return (List<Car>) carrepo.findByCarName(carName);
		
	}
	
	public Car updateCar(Car car)
	{
		Car existingcar=carrepo.findById(car.getCarId()).get();
		existingcar.setCarName(car.getCarName());
		existingcar.setCarColor(car.getCarColor());
		existingcar.setCarPrice(car.getCarPrice());
		return carrepo.save(existingcar);
	}
	public String deleteCar(String carId) {
		carrepo.deleteById(carId);
		return carId+ "car deleted";
		
	}

}
